/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FinalProject;

/**
 *
 * @author elich
 */
public class ClassGroupClass {

    /**
     * @return the ClassGroupCode
     */
    public String getClassGroupCode() {
        return ClassGroupCode;
    }

    /**
     * @param ClassGroupCode the ClassGroupCode to set
     */
    public void setClassGroupCode(String ClassGroupCode) {
        this.ClassGroupCode = ClassGroupCode;
    }

   
      private String ClassGroupCode;
}
