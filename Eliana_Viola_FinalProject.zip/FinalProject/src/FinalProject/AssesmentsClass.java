/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FinalProject;

import java.sql.Date;

/**
 *
 * @author elich
 */
public class AssesmentsClass {

    /**
     * @return the givenDate
     */
    public Date getGivenDate() {
        return givenDate;
    }

    /**
     * @param givenDate the givenDate to set
     */
    public void setGivenDate(Date givenDate) {
        this.givenDate = givenDate;
    }

    /**
     * @return the AssigmentID
     */
    public int getAssigmentID() {
        return AssigmentID;
    }

    /**
     * @param AssigmentID the AssigmentID to set
     */
    public void setAssigmentID(int AssigmentID) {
        this.AssigmentID = AssigmentID;
    }

    /**
     * @return the AssesmentTitle
     */
    public String getAssesmentTitle() {
        return AssesmentTitle;
    }

    /**
     * @param AssesmentTitle the AssesmentTitle to set
     */
    public void setAssesmentTitle(String AssesmentTitle) {
        this.AssesmentTitle = AssesmentTitle;
    }

    /**
     * @return the Grade
     */
    public int getGrade() {
        return Grade;
    }

    /**
     * @param Grade the Grade to set
     */
    public void setGrade(int Grade) {
        this.Grade = Grade;
    }

    /**
     * @return the dueDate
     */
    public Date getDueDate() {
        return dueDate;
    }

    /**
     * @param dueDate the dueDate to set
     */
    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    /**
     * @return the PercentageWorth
     */
    public int getPercentageWorth() {
        return PercentageWorth;
    }

    /**
     * @param PercentageWorth the PercentageWorth to set
     */
    public void setPercentageWorth(int PercentageWorth) {
        this.PercentageWorth = PercentageWorth;
    }
      private int AssigmentID;

    private String AssesmentTitle;

    private int Grade;

    private Date dueDate;

    private int PercentageWorth;
    
    private Date givenDate;
    
}
