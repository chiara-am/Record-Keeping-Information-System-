/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FinalProject;
import java.util.Calendar;
import java.sql.Date;

/**
 *
 * @author elich
 */
public class PersonClass {

    /**
     * @return the Name
     */
    public String getName() {
        return Name;
    }

    /**
     * @param Name the Name to set
     */
    public void setName(String Name) {
        this.Name = Name;
    }

    /**
     * @return the Surname
     */
    public String getSurname() {
        return Surname;
    }

    /**
     * @param Surname the Surname to set
     */
    public void setSurname(String Surname) {
        this.Surname = Surname;
    }

    /**
     * @return the PPSNumber
     */
    public String getPPSNumber() {
        return PPSNumber;
    }

    /**
     * @param PPSNumber the PPSNumber to set
     */
    public void setPPSNumber(String PPSNumber) {
        this.PPSNumber = PPSNumber;
    }

    /**
     * @return the DOB
     */
    public Date getDOB() {
        return DOB;
    }

    /**
     * @param DOB the DOB to set
     */
    public void setDOB(Date DOB) {
        this.DOB = DOB;
    }

    /**
     * @return the AddressOne
     */
    public String getAddressOne() {
        return AddressOne;
    }

    /**
     * @param AddressOne the AddressOne to set
     */
    public void setAddressOne(String AddressOne) {
        this.AddressOne = AddressOne;
    }

    /**
     * @return the AddressTwo
     */
    public String getAddressTwo() {
        return AddressTwo;
    }

    /**
     * @param AddressTwo the AddressTwo to set
     */
    public void setAddressTwo(String AddressTwo) {
        this.AddressTwo = AddressTwo;
    }

    /**
     * @return the AddressThree
     */
    public String getAddressThree() {
        return AddressThree;
    }

    /**
     * @param AddressThree the AddressThree to set
     */
    public void setAddressThree(String AddressThree) {
        this.AddressThree = AddressThree;
    }

    /**
     * @return the Eircode
     */
    public String getEircode() {
        return Eircode;
    }

    /**
     * @param Eircode the Eircode to set
     */
    public void setEircode(String Eircode) {
        this.Eircode = Eircode;
    }

    /**
     * @return the County
     */
    public String getCounty() {
        return County;
    }

    /**
     * @param County the County to set
     */
    public void setCounty(String County) {
        this.County = County;
    }
    private String Name;

    private String Surname;

    private String PPSNumber;

    private Date DOB;

    private String AddressOne;

    private String AddressTwo;

    private String AddressThree;

    private String Eircode;

    private String County;

    
}
