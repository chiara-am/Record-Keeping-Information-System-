/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FinalProject;

/**
 *
 * @author elich
 */
public class CourseClass {

    /**
     * @return the CourseCode
     */
    public String getCourseCode() {
        return CourseCode;
    }

    /**
     * @param CourseCode the CourseCode to set
     */
    public void setCourseCode(String CourseCode) {
        this.CourseCode = CourseCode;
    }

    /**
     * @return the CourseCode
     */
 
    /**
     * @return the CourseTitle
     */
    public String getCourseTitle() {
        return CourseTitle;
    }

    /**
     * @param CourseTitle the CourseTitle to set
     */
    public void setCourseTitle(String CourseTitle) {
        this.CourseTitle = CourseTitle;
    }
    
    private String CourseCode;

    private String CourseTitle;

    
}
