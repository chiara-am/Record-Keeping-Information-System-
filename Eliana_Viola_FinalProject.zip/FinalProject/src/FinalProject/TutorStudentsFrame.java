/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package FinalProject;

import javax.swing.table.DefaultTableModel;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author elich
 */
public class TutorStudentsFrame extends javax.swing.JFrame {

    private static final java.util.logging.Logger logger = java.util.logging.Logger.getLogger(TutorStudentsFrame.class.getName());
    //to  connect to the database
    public static String url = "jdbc:mysql://127.0.0.1:3306/";
    //database name
    public static String dbName = "finalproject";
    //username for connecting to local host
    public static String userName = "root";
    //password for connecting to local host
    public static String password = "Firu1611";

    /// These booleans control whether we are editing, adding or deleting Students
    boolean editAssesments, uploadAssesments, editdetails;

    boolean startframe; // when search is clicked, allows edit/delete/add of student info

    // Objects that represent real world data
    private TeacherClass teacher;// currently logged-in teacher
    StudentClass student = new StudentClass(); // stores student details
    CourseClass course = new CourseClass(); // stores course detail
    AssesmentsClass assesments = new AssesmentsClass();// stores assessment details
    ModuleClass module = new ModuleClass(); // stores module details

    // Constructor used after teacher logs in
    // Stores teacher details and shows their name on screen
    public TutorStudentsFrame(TeacherClass teacher) {
        initComponents();
        this.teacher = teacher; // store the teacher object
        jLabelTeacherName.setText(teacher.getName() + " " + teacher.getSurname());
    }

    // Default constructor
    public TutorStudentsFrame() {
        initComponents();
    }

    // Enables all student information fields so they can be edited
    private void setFieldsEnabledStudent() {
        setFieldsEnabledStudentsInfo(true);
    }

    // Enables all assessment fields so they can be edited
    private void setFieldsEnabledAssesments() {
        setFieldsEnabledStudentAssesments(true);
    }

    // Disables all student information fields
    private void setFieldsDisabledStudent() {
        setFieldsEnabledStudentsInfo(false);
    }

    // Disables all assessment fields
    private void setFieldsDisabledAssesments() {
        setFieldsEnabledStudentAssesments(false);
    }

    // General method to enable or disable student text fields
    private void setFieldsEnabledStudentsInfo(boolean enabled) {
        jTextFieldStudentFirstName.setEnabled(enabled);
        jTextFieldStudentSurname.setEnabled(enabled);
        jTextFieldPPSNumber.setEnabled(enabled);
        jTextFieldDOB.setEnabled(enabled);
        jTextFieldClassGroupCode.setEnabled(enabled);
        jTextFieldAddressLine2.setEnabled(enabled);
        jTextFieldAddedLine3.setEnabled(enabled);
        jTextFieldCounty.setEnabled(enabled);
        jTextFieldAddressLine1.setEnabled(enabled);

    }

    // General method to enable or disable assessment text fields
    private void setFieldsEnabledStudentAssesments(boolean enabled) {
        jTextFieldAssigmentID.setEnabled(enabled);
        jTextFieldAssigmentName.setEnabled(enabled);
        jTextFieldGrade.setEnabled(enabled);
        jTextFieldGivenDate.setEnabled(enabled);
        jTextFieldDueDate.setEnabled(enabled);
        jTextFieldCPercentageWorth.setEnabled(enabled);
        jTextFieldModuleCode.setEnabled(enabled);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jFrame1 = new javax.swing.JFrame();
        jLabelCourseNameTitle1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanelStudentInfo = new javax.swing.JPanel();
        jLabelAssigmentID = new javax.swing.JLabel();
        jTextFieldAssigmentID = new javax.swing.JTextField();
        jLabelAssigmentName = new javax.swing.JLabel();
        jTextFieldAssigmentName = new javax.swing.JTextField();
        jLabelEmail = new javax.swing.JLabel();
        jLabelModuleCode = new javax.swing.JLabel();
        jTextFieldModuleCode = new javax.swing.JTextField();
        jTextFieldGrade = new javax.swing.JTextField();
        jLabelGrade = new javax.swing.JLabel();
        jLabelGivenDate = new javax.swing.JLabel();
        jTextFieldGivenDate = new javax.swing.JTextField();
        jLabelDueDate = new javax.swing.JLabel();
        jTextFieldDueDate = new javax.swing.JTextField();
        jTextFieldCPercentageWorth = new javax.swing.JTextField();
        jLabelPercentageWorth = new javax.swing.JLabel();
        jButtonAddRecords = new javax.swing.JButton();
        jButtonEditRecords = new javax.swing.JButton();
        jButtonCancelRecords = new javax.swing.JButton();
        jButtonSaveRecords = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jLabelStudentsDetails1 = new javax.swing.JLabel();
        jLabelCourseNameTitle = new javax.swing.JLabel();
        jLabelCourseIDTitle = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanelSearchStudents = new javax.swing.JPanel();
        jLabelSeacrhStudent = new javax.swing.JLabel();
        jButtonSearch = new javax.swing.JButton();
        jComboBoxSearch = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        jButtonLogOut = new javax.swing.JButton();
        jLabelTeacherName = new javax.swing.JLabel();
        jButtonMyClasses = new javax.swing.JButton();
        jLabelLogo = new javax.swing.JLabel();
        jLabelCourseName = new javax.swing.JLabel();
        jLabelCourseID = new javax.swing.JLabel();
        jPanelStudentInfo1 = new javax.swing.JPanel();
        jLabelStudentFirstName = new javax.swing.JLabel();
        jTextFieldStudentFirstName = new javax.swing.JTextField();
        jLabelStudentSurname = new javax.swing.JLabel();
        jTextFieldStudentSurname = new javax.swing.JTextField();
        jLabelEmail1 = new javax.swing.JLabel();
        jLabelAddressLine1 = new javax.swing.JLabel();
        jTextFieldAddressLine1 = new javax.swing.JTextField();
        jLabelAddressLine2 = new javax.swing.JLabel();
        jTextFieldAddressLine2 = new javax.swing.JTextField();
        jTextFieldAddedLine3 = new javax.swing.JTextField();
        jTextFieldCounty = new javax.swing.JTextField();
        jLabelAddressLine3 = new javax.swing.JLabel();
        jLabelCounty = new javax.swing.JLabel();
        jButtonEditDetails = new javax.swing.JButton();
        jTextFieldStudentID = new javax.swing.JTextField();
        jLabelStudentID = new javax.swing.JLabel();
        jButtonSaveDetails = new javax.swing.JButton();
        jButtonCancelDetails = new javax.swing.JButton();
        jLabelPPS = new javax.swing.JLabel();
        jTextFieldPPSNumber = new javax.swing.JTextField();
        jLabelClassCode = new javax.swing.JLabel();
        jTextFieldDOB = new javax.swing.JTextField();
        jTextFieldClassGroupCode = new javax.swing.JTextField();
        jPanel4 = new javax.swing.JPanel();
        jLabelStudentsDetails = new javax.swing.JLabel();
        jLabelDOB = new javax.swing.JLabel();
        jLabelTeacherName1 = new javax.swing.JLabel();
        jLabelCourseNameTitle2 = new javax.swing.JLabel();
        jLabelCourseNameTitle3 = new javax.swing.JLabel();
        jPanelStudentInfo2 = new javax.swing.JPanel();
        jLabelEmail2 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabelStudentsDetails2 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTableAssesmentsTable = new javax.swing.JTable();

        javax.swing.GroupLayout jFrame1Layout = new javax.swing.GroupLayout(jFrame1.getContentPane());
        jFrame1.getContentPane().setLayout(jFrame1Layout);
        jFrame1Layout.setHorizontalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jFrame1Layout.setVerticalGroup(
            jFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        jLabelCourseNameTitle1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabelCourseNameTitle1.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCourseNameTitle1.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCourseNameTitle1.setText("Class Details");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(96, 0, -1, -1));

        jPanelStudentInfo.setBackground(new java.awt.Color(255, 255, 255));
        jPanelStudentInfo.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(39, 77, 119), 2, true));
        jPanelStudentInfo.setForeground(new java.awt.Color(102, 102, 102));
        jPanelStudentInfo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelAssigmentID.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelAssigmentID.setText("Assigment ID:");
        jPanelStudentInfo.add(jLabelAssigmentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 50, 110, 30));

        jTextFieldAssigmentID.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jTextFieldAssigmentID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldAssigmentIDActionPerformed(evt);
            }
        });
        jPanelStudentInfo.add(jTextFieldAssigmentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 50, 230, 30));

        jLabelAssigmentName.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelAssigmentName.setText("Name: ");
        jPanelStudentInfo.add(jLabelAssigmentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 110, 30));

        jTextFieldAssigmentName.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jPanelStudentInfo.add(jTextFieldAssigmentName, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 90, 230, 31));
        jPanelStudentInfo.add(jLabelEmail, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, -1, 30));

        jLabelModuleCode.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelModuleCode.setText("Module Code:");
        jPanelStudentInfo.add(jLabelModuleCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 320, 110, 30));

        jTextFieldModuleCode.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jTextFieldModuleCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldModuleCodeActionPerformed(evt);
            }
        });
        jPanelStudentInfo.add(jTextFieldModuleCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 320, 230, 30));

        jTextFieldGrade.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jTextFieldGrade.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldGradeActionPerformed(evt);
            }
        });
        jPanelStudentInfo.add(jTextFieldGrade, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 140, 230, 30));

        jLabelGrade.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelGrade.setText("Grade: ");
        jPanelStudentInfo.add(jLabelGrade, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 140, 110, 30));

        jLabelGivenDate.setText("Given Date:");
        jPanelStudentInfo.add(jLabelGivenDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 110, 30));

        jTextFieldGivenDate.setToolTipText("YYYY - MM - DD");
        jPanelStudentInfo.add(jTextFieldGivenDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 230, 30));

        jLabelDueDate.setText("Due Date:");
        jPanelStudentInfo.add(jLabelDueDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 110, 30));

        jTextFieldDueDate.setToolTipText("YYYY - MM - DD");
        jPanelStudentInfo.add(jTextFieldDueDate, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 240, 230, 30));
        jPanelStudentInfo.add(jTextFieldCPercentageWorth, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 280, 230, 30));

        jLabelPercentageWorth.setText("Percentage Worth:");
        jPanelStudentInfo.add(jLabelPercentageWorth, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 280, 100, 30));

        jButtonAddRecords.setBackground(new java.awt.Color(39, 77, 119));
        jButtonAddRecords.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonAddRecords.setForeground(new java.awt.Color(255, 255, 255));
        jButtonAddRecords.setText("Add Records");
        jButtonAddRecords.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonAddRecordsActionPerformed(evt);
            }
        });
        jPanelStudentInfo.add(jButtonAddRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 380, 280, 40));

        jButtonEditRecords.setBackground(new java.awt.Color(39, 77, 119));
        jButtonEditRecords.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonEditRecords.setForeground(new java.awt.Color(255, 255, 255));
        jButtonEditRecords.setText("Edit Records");
        jButtonEditRecords.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditRecordsActionPerformed(evt);
            }
        });
        jPanelStudentInfo.add(jButtonEditRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 450, 280, 40));

        jButtonCancelRecords.setBackground(new java.awt.Color(139, 140, 137));
        jButtonCancelRecords.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonCancelRecords.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCancelRecords.setText("Cancel");
        jButtonCancelRecords.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelRecordsActionPerformed(evt);
            }
        });
        jPanelStudentInfo.add(jButtonCancelRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 510, 130, 40));

        jButtonSaveRecords.setBackground(new java.awt.Color(139, 140, 137));
        jButtonSaveRecords.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonSaveRecords.setForeground(new java.awt.Color(255, 255, 255));
        jButtonSaveRecords.setText("Save");
        jButtonSaveRecords.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaveRecordsActionPerformed(evt);
            }
        });
        jPanelStudentInfo.add(jButtonSaveRecords, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 510, 120, 40));

        jPanel5.setBackground(new java.awt.Color(39, 77, 119));

        jLabelStudentsDetails1.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabelStudentsDetails1.setForeground(new java.awt.Color(255, 255, 255));
        jLabelStudentsDetails1.setText("Assesments Details");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(105, Short.MAX_VALUE)
                .addComponent(jLabelStudentsDetails1)
                .addGap(101, 101, 101))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabelStudentsDetails1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanelStudentInfo.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 380, 30));

        jPanel1.add(jPanelStudentInfo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1150, 200, 380, 580));

        jLabelCourseNameTitle.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabelCourseNameTitle.setText("Course");
        jPanel1.add(jLabelCourseNameTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 90, 50, 20));

        jLabelCourseIDTitle.setFont(new java.awt.Font("SansSerif", 1, 12)); // NOI18N
        jLabelCourseIDTitle.setText("Course ID");
        jPanel1.add(jLabelCourseIDTitle, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 160, 76, 20));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new javax.swing.BoxLayout(jPanel2, javax.swing.BoxLayout.LINE_AXIS));
        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, -1));

        jPanelSearchStudents.setBackground(new java.awt.Color(255, 255, 255));
        jPanelSearchStudents.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(39, 77, 119), 2, true));

        jLabelSeacrhStudent.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabelSeacrhStudent.setText("Search Student :");

        jButtonSearch.setBackground(new java.awt.Color(39, 77, 119));
        jButtonSearch.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonSearch.setForeground(new java.awt.Color(255, 255, 255));
        jButtonSearch.setText("Search");
        jButtonSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSearchActionPerformed(evt);
            }
        });

        jComboBoxSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBoxSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanelSearchStudentsLayout = new javax.swing.GroupLayout(jPanelSearchStudents);
        jPanelSearchStudents.setLayout(jPanelSearchStudentsLayout);
        jPanelSearchStudentsLayout.setHorizontalGroup(
            jPanelSearchStudentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanelSearchStudentsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabelSeacrhStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jComboBoxSearch, 0, 434, Short.MAX_VALUE)
                .addGap(32, 32, 32)
                .addComponent(jButtonSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40))
        );
        jPanelSearchStudentsLayout.setVerticalGroup(
            jPanelSearchStudentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanelSearchStudentsLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanelSearchStudentsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabelSeacrhStudent, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBoxSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(28, Short.MAX_VALUE))
        );

        jPanel1.add(jPanelSearchStudents, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 80, 770, 100));

        jPanel3.setBackground(new java.awt.Color(39, 77, 119));

        jButtonLogOut.setBackground(new java.awt.Color(39, 77, 119));
        jButtonLogOut.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonLogOut.setForeground(new java.awt.Color(255, 255, 255));
        jButtonLogOut.setText("Log out");
        jButtonLogOut.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonLogOut.setBorderPainted(false);
        jButtonLogOut.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonLogOutActionPerformed(evt);
            }
        });

        jLabelTeacherName.setBackground(new java.awt.Color(39, 77, 119));
        jLabelTeacherName.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        jLabelTeacherName.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTeacherName.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);

        jButtonMyClasses.setBackground(new java.awt.Color(39, 77, 119));
        jButtonMyClasses.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonMyClasses.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMyClasses.setText("My Classes");
        jButtonMyClasses.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));
        jButtonMyClasses.setBorderPainted(false);
        jButtonMyClasses.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMyClassesActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(889, Short.MAX_VALUE)
                .addComponent(jButtonLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonMyClasses, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabelTeacherName, javax.swing.GroupLayout.PREFERRED_SIZE, 333, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLabelTeacherName, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButtonMyClasses, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButtonLogOut, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 4, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 0, 1470, 70));

        jLabelLogo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/FinalProject/gtilogosmall.png"))); // NOI18N
        jPanel1.add(jLabelLogo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabelCourseName.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCourseName.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabelCourseName.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabelCourseName.setToolTipText("");
        jLabelCourseName.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(39, 77, 119), 2, true));
        jPanel1.add(jLabelCourseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 370, 40));

        jLabelCourseID.setBackground(new java.awt.Color(255, 255, 255));
        jLabelCourseID.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jLabelCourseID.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(39, 77, 119), 2, true));
        jPanel1.add(jLabelCourseID, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 180, 200, 40));

        jPanelStudentInfo1.setBackground(new java.awt.Color(255, 255, 255));
        jPanelStudentInfo1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(39, 77, 119), 2, true));
        jPanelStudentInfo1.setForeground(new java.awt.Color(102, 102, 102));
        jPanelStudentInfo1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabelStudentFirstName.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelStudentFirstName.setText("First Name: ");
        jPanelStudentInfo1.add(jLabelStudentFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 70, 110, 30));

        jTextFieldStudentFirstName.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jTextFieldStudentFirstName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldStudentFirstNameActionPerformed(evt);
            }
        });
        jPanelStudentInfo1.add(jTextFieldStudentFirstName, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 70, 230, 30));

        jLabelStudentSurname.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelStudentSurname.setText("Surname:");
        jPanelStudentInfo1.add(jLabelStudentSurname, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 110, 110, 30));

        jTextFieldStudentSurname.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jPanelStudentInfo1.add(jTextFieldStudentSurname, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 110, 230, 31));
        jPanelStudentInfo1.add(jLabelEmail1, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, -1, 30));

        jLabelAddressLine1.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelAddressLine1.setText("Address Line 1:");
        jPanelStudentInfo1.add(jLabelAddressLine1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 310, 110, 30));

        jTextFieldAddressLine1.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jTextFieldAddressLine1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldAddressLine1ActionPerformed(evt);
            }
        });
        jPanelStudentInfo1.add(jTextFieldAddressLine1, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 310, 230, 30));

        jLabelAddressLine2.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelAddressLine2.setText("Address Line 2:");
        jPanelStudentInfo1.add(jLabelAddressLine2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 350, 110, 30));

        jTextFieldAddressLine2.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jPanelStudentInfo1.add(jTextFieldAddressLine2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 350, 230, 30));

        jTextFieldAddedLine3.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jTextFieldAddedLine3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldAddedLine3ActionPerformed(evt);
            }
        });
        jPanelStudentInfo1.add(jTextFieldAddedLine3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 390, 230, 33));

        jTextFieldCounty.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jTextFieldCounty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldCountyActionPerformed(evt);
            }
        });
        jPanelStudentInfo1.add(jTextFieldCounty, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 440, 230, 36));

        jLabelAddressLine3.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelAddressLine3.setText("Address Line 3:");
        jPanelStudentInfo1.add(jLabelAddressLine3, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 390, 110, 33));

        jLabelCounty.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelCounty.setText("County:");
        jPanelStudentInfo1.add(jLabelCounty, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 440, 110, 36));

        jButtonEditDetails.setBackground(new java.awt.Color(39, 77, 119));
        jButtonEditDetails.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonEditDetails.setForeground(new java.awt.Color(255, 255, 255));
        jButtonEditDetails.setText("Edit Details");
        jButtonEditDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonEditDetailsActionPerformed(evt);
            }
        });
        jPanelStudentInfo1.add(jButtonEditDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 490, -1, 37));

        jTextFieldStudentID.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jTextFieldStudentID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextFieldStudentIDActionPerformed(evt);
            }
        });
        jPanelStudentInfo1.add(jTextFieldStudentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 150, 230, 30));

        jLabelStudentID.setFont(new java.awt.Font("SansSerif", 0, 12)); // NOI18N
        jLabelStudentID.setText("Student ID:");
        jPanelStudentInfo1.add(jLabelStudentID, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 150, 110, 30));

        jButtonSaveDetails.setBackground(new java.awt.Color(139, 140, 137));
        jButtonSaveDetails.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonSaveDetails.setForeground(new java.awt.Color(255, 255, 255));
        jButtonSaveDetails.setText("Save");
        jButtonSaveDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSaveDetailsActionPerformed(evt);
            }
        });
        jPanelStudentInfo1.add(jButtonSaveDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 490, 90, 37));

        jButtonCancelDetails.setBackground(new java.awt.Color(139, 140, 137));
        jButtonCancelDetails.setFont(new java.awt.Font("SansSerif", 1, 14)); // NOI18N
        jButtonCancelDetails.setForeground(new java.awt.Color(255, 255, 255));
        jButtonCancelDetails.setText("Cancel");
        jButtonCancelDetails.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonCancelDetailsActionPerformed(evt);
            }
        });
        jPanelStudentInfo1.add(jButtonCancelDetails, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 490, 83, 37));

        jLabelPPS.setText("PPS Number:");
        jPanelStudentInfo1.add(jLabelPPS, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 190, 110, 30));
        jPanelStudentInfo1.add(jTextFieldPPSNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 190, 230, 30));

        jLabelClassCode.setText("Class Group Code");
        jPanelStudentInfo1.add(jLabelClassCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 110, 30));

        jTextFieldDOB.setToolTipText("YYYY - MM - DD");
        jPanelStudentInfo1.add(jTextFieldDOB, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 230, 230, 30));
        jPanelStudentInfo1.add(jTextFieldClassGroupCode, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 270, 230, 30));

        jPanel4.setBackground(new java.awt.Color(39, 77, 119));

        jLabelStudentsDetails.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabelStudentsDetails.setForeground(new java.awt.Color(255, 255, 255));
        jLabelStudentsDetails.setText("Student Details");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(118, 118, 118)
                .addComponent(jLabelStudentsDetails)
                .addContainerGap(119, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel4Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabelStudentsDetails, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanelStudentInfo1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 370, -1));

        jLabelDOB.setText("Date of Birth:");
        jPanelStudentInfo1.add(jLabelDOB, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 230, 110, 30));

        jPanel1.add(jPanelStudentInfo1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 240, 370, 540));

        jLabelTeacherName1.setBackground(new java.awt.Color(39, 77, 119));
        jLabelTeacherName1.setFont(new java.awt.Font("SansSerif", 1, 36)); // NOI18N
        jLabelTeacherName1.setForeground(new java.awt.Color(255, 255, 255));
        jLabelTeacherName1.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jPanel1.add(jLabelTeacherName1, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 770, 333, 30));

        jLabelCourseNameTitle2.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabelCourseNameTitle2.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCourseNameTitle2.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCourseNameTitle2.setText("Class Details");
        jPanel1.add(jLabelCourseNameTitle2, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 90, 50, 20));

        jLabelCourseNameTitle3.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabelCourseNameTitle3.setForeground(new java.awt.Color(255, 255, 255));
        jLabelCourseNameTitle3.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabelCourseNameTitle3.setText("Class Details");
        jPanel1.add(jLabelCourseNameTitle3, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 90, 50, 20));

        jPanelStudentInfo2.setBackground(new java.awt.Color(255, 255, 255));
        jPanelStudentInfo2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(39, 77, 119), 2, true));
        jPanelStudentInfo2.setForeground(new java.awt.Color(102, 102, 102));
        jPanelStudentInfo2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanelStudentInfo2.add(jLabelEmail2, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 140, -1, 30));

        jPanel6.setBackground(new java.awt.Color(39, 77, 119));

        jLabelStudentsDetails2.setFont(new java.awt.Font("SansSerif", 1, 18)); // NOI18N
        jLabelStudentsDetails2.setForeground(new java.awt.Color(255, 255, 255));
        jLabelStudentsDetails2.setText("Assesments Table");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(304, Short.MAX_VALUE)
                .addComponent(jLabelStudentsDetails2)
                .addGap(272, 272, 272))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabelStudentsDetails2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        jPanelStudentInfo2.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 740, -1));

        jTableAssesmentsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Assesment ID", "Name", "Grade", "Given Date", "Due Date", "Range", "Module Code"
            }
        ));
        jScrollPane2.setViewportView(jTableAssesmentsTable);

        jPanelStudentInfo2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 40, 720, 530));

        jPanel1.add(jPanelStudentInfo2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 200, 740, 580));

        getContentPane().add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jTextFieldModuleCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldModuleCodeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldModuleCodeActionPerformed

    private void jTextFieldGradeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldGradeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldGradeActionPerformed

    private void jTextFieldAssigmentIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldAssigmentIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldAssigmentIDActionPerformed

    private void jButtonLogOutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonLogOutActionPerformed
        // Create a new LogInFrame window
        LogInFrame homepage = new LogInFrame();

        // Make the LogInFrame visible on the screen
        homepage.setVisible(true);

        // Close the current window (TutorStudentsFrame)
        // Prevents multiple windows staying open at the same time
        this.dispose();
    }//GEN-LAST:event_jButtonLogOutActionPerformed

    private void jComboBoxSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBoxSearchActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBoxSearchActionPerformed

    private void jButtonSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSearchActionPerformed
        startframe = true;  // enable editing after search

        // Disable student input fields during search
        setFieldsDisabledStudent();

        // Disable assessment input fields during search
        setFieldsDisabledAssesments();
        jTableAssesmentsTable.setEnabled(false);

        // Disable student ID field to prevent edits
        jTextFieldStudentID.setEnabled(false);

        // Ensure table editing stops when focus is lost
        jTableAssesmentsTable.putClientProperty("terminateEditOnFocusLost", Boolean.TRUE);

        // Get the selected student from combo boxt
        String selected = jComboBoxSearch.getSelectedItem().toString().trim();
        String studentIDStr = selected.split(" - ")[0]; // get student ID part
        int studentID = Integer.parseInt(studentIDStr);
        student.setStudentID(studentID); // store student ID in object

        try {
            // Create a connection to the database
            Connection con = DriverManager.getConnection(url + dbName, userName, password);

            // SQL to retrieve student and course info
            String sql = "SELECT s.*, c.Course_Code, c.Title AS StudentCourse  FROM students s JOIN class_group cg ON s.Class_Group_Code = cg.Class_Group_Code JOIN course c ON cg.Course_Code = c.Course_Code  WHERE s.Student_ID = ?;";
            PreparedStatement prest = con.prepareStatement(sql);
            prest.setInt(1, student.getStudentID());
            ResultSet res = prest.executeQuery();

            // Populate student and course objects with query result
            while (res.next()) {
                student.setStudentID(res.getInt(1));
                student.setName(res.getString(2));
                student.setSurname(res.getString(3));
                student.setPPSNumber(res.getString(4));
                student.setDOB(res.getDate(5));
                student.setAddressOne(res.getString(6));
                student.setAddressTwo(res.getString(7));
                student.setAddressThree(res.getString(8));
                student.setCounty(res.getString(9));
                course.setCourseCode(res.getString(11));
                course.setCourseTitle(res.getString(12));
                student.setClassGroup(res.getString(10));
                course.setCourseCode(res.getString(11));
                course.setCourseTitle(res.getString(12));

                // Display student info in text fields
                jTextFieldStudentFirstName.setText(student.getName());
                jTextFieldStudentSurname.setText(student.getSurname());
                jTextFieldStudentID.setText(student.getStudentID() + "");
                jTextFieldPPSNumber.setText(student.getPPSNumber());
                jTextFieldDOB.setText(student.getDOB() + "");
                jTextFieldAddressLine1.setText(student.getAddressOne());
                jTextFieldAddressLine2.setText(student.getAddressTwo());
                jTextFieldAddedLine3.setText(student.getAddressThree());
                jTextFieldCounty.setText(student.getCounty());
                jTextFieldClassGroupCode.setText(student.getClassGroup());

                // Display course details in labels
                jLabelCourseID.setText(course.getCourseCode());
                jLabelCourseName.setText(course.getCourseTitle());
            }

        } catch (SQLException e) {
            // Display error if student query fails
            System.out.print("Not Connected" + e);
        }
        try {
            Connection con = DriverManager.getConnection(url + dbName, userName, password);

            // SQL to retrieve assessments for selected student
            String sql = "SELECT a.Assigments_ID, a.Name, ahs.Grade, a.Given_Date, ahs.Module_Code, a.Due_Date, a.Percentage_Worth FROM assesments a JOIN assesments_has_students ahs ON a.Assigments_ID = ahs.Assigments_ID JOIN module m ON m.Module_Code = ahs.Module_Code WHERE ahs.student_id = ? AND m.Staff_ID = ?;";
            PreparedStatement prest = con.prepareStatement(sql);
            prest.setInt(1, student.getStudentID());
            prest.setInt(2, teacher.getStaffID());
            ResultSet res = prest.executeQuery();

            // Create table model for assessments
            DefaultTableModel model = new DefaultTableModel();
            model.addColumn("Assessment ID");
            model.addColumn("Name");
            model.addColumn("Grade");
            model.addColumn("Given Date");
            model.addColumn("Due Date");
            model.addColumn("Range");
            model.addColumn("Module Code");

            // Populate the table model with assessment data
            while (res.next()) {
                assesments.setAssigmentID(res.getInt("Assigments_ID"));
                assesments.setAssesmentTitle(res.getString("Name"));
                assesments.setGrade(Integer.parseInt(res.getString("Grade")));
                assesments.setGivenDate(res.getDate("Given_Date"));
                assesments.setDueDate(res.getDate("Due_Date"));
                assesments.setPercentageWorth(Integer.parseInt(res.getString("Percentage_Worth")));
                module.setModuleCode(res.getString("Module_Code"));

                // Add a row to the table using getter methods
                model.addRow(new Object[]{
                    assesments.getAssigmentID(),
                    assesments.getAssesmentTitle(),
                    assesments.getGrade(),
                    assesments.getGivenDate(),
                    assesments.getDueDate(),
                    assesments.getPercentageWorth(),
                    module.getModuleCode(),});

            }

            // Set the table model for assessments table
            jTableAssesmentsTable.setModel(model);

        } catch (SQLException e) {
            // Print stack trace if assessment query fails
        }

    }//GEN-LAST:event_jButtonSearchActionPerformed


    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        startframe = false; // disable editing until a student is searched

        // Disable all save and cancel buttons and fields initially
        jButtonSaveDetails.setEnabled(false);
        jButtonSaveRecords.setEnabled(false);
        jButtonCancelDetails.setEnabled(false);
        jButtonCancelRecords.setEnabled(false);
        jTextFieldStudentID.setEnabled(false);
        setFieldsDisabledAssesments();
        setFieldsDisabledStudent();

        searchStudent();// populate student combo box or initial data

    }//GEN-LAST:event_formWindowOpened

    private void jButtonAddRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonAddRecordsActionPerformed

        if (startframe) {
            // Enable add mode for assessments
            uploadAssesments = true;

            // Disable edit mode to avoid modifying existing records
            editAssesments = false;

            // Enable all assessment input fields for entering new data
            setFieldsEnabledAssesments();
            jButtonEditDetails.setEnabled(false);
            jButtonAddRecords.setEnabled(false);
            jButtonEditRecords.setEnabled(false);
            jButtonSaveDetails.setEnabled(false);
            jButtonCancelDetails.setEnabled(false);

            // Enable save and cancel buttons for adding records
            jButtonSaveRecords.setEnabled(true);
            jButtonCancelRecords.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(rootPane, "Please search for a student first.");
        }
    }//GEN-LAST:event_jButtonAddRecordsActionPerformed

    private void jButtonCancelRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelRecordsActionPerformed
        // Ask the user for confirmation before canceling
        int answer = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to cancel?",
                "Confirm",
                JOptionPane.YES_NO_OPTION
        );

        if (answer == JOptionPane.YES_OPTION) {

            // Reset student input fields to disabled
            setFieldsDisabledStudent();
            jButtonEditDetails.setEnabled(true);
            jButtonAddRecords.setEnabled(true);
            jButtonEditRecords.setEnabled(true);
            jButtonSaveDetails.setEnabled(true);
            jButtonCancelDetails.setEnabled(true);
            jButtonSaveRecords.setEnabled(true);
            jButtonCancelRecords.setEnabled(true);

            // Disable assessment table
            jTableAssesmentsTable.setEnabled(false);

            // Reset text fields to current values of the selected student
            jTextFieldAssigmentID.setText("");
            jTextFieldAssigmentName.setText("");
            jTextFieldStudentID.setText("");
            jTextFieldGrade.setText("");
            jTextFieldGivenDate.setText("");
            jTextFieldDueDate.setText("");
            jTextFieldCPercentageWorth.setText("");
            jTextFieldModuleCode.setText("");

            //Disable Fields
            setFieldsDisabledAssesments();

        }
    }//GEN-LAST:event_jButtonCancelRecordsActionPerformed

    private void jButtonMyClassesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMyClassesActionPerformed
        // Open the teacher's classes frame
        TutorClassesFrame classesframe = new TutorClassesFrame(teacher);
        classesframe.setVisible(true);

        // Close the current student frame
        this.dispose();
    }//GEN-LAST:event_jButtonMyClassesActionPerformed

    private void jButtonEditRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditRecordsActionPerformed
        if (startframe) {
            // Enable editing on the assessments table
            jTableAssesmentsTable.setEnabled(true);
            jButtonEditDetails.setEnabled(false);
            jButtonAddRecords.setEnabled(false);
            jButtonEditRecords.setEnabled(false);
            jButtonSaveDetails.setEnabled(false);
            jButtonCancelDetails.setEnabled(false);

            // Enable save and cancel buttons for assessment edits
            jButtonSaveRecords.setEnabled(true);
            jButtonCancelRecords.setEnabled(true);

            // Set flags indicating editing mode
            editAssesments = true;
            uploadAssesments = false;
        } else {
            JOptionPane.showMessageDialog(rootPane, "Please search for a student first.");
        }
    }//GEN-LAST:event_jButtonEditRecordsActionPerformed

    private void jButtonSaveRecordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaveRecordsActionPerformed
        if (editAssesments) {
            int row = jTableAssesmentsTable.getSelectedRow();

            // Ensure a row is selected
            if (row == -1) {
                JOptionPane.showMessageDialog(this, "Select a row first");
                return;
            }

            // Stop cell editing to retrieve values
            if (jTableAssesmentsTable.isEditing()) {
                jTableAssesmentsTable.getCellEditor().stopCellEditing();
            }

            try (
                    Connection con = DriverManager.getConnection(url + dbName, userName, password)) {

                // Get values from selected table row
                // Get selected row
                int selectedRow = jTableAssesmentsTable.getSelectedRow();

                // Get values from selected table row
                int assessmentId = Integer.parseInt(jTableAssesmentsTable.getValueAt(selectedRow, 0).toString());
                String name = jTableAssesmentsTable.getValueAt(selectedRow, 1).toString();
                int grade = Integer.parseInt(jTableAssesmentsTable.getValueAt(selectedRow, 2).toString());
                java.sql.Date givenDate = java.sql.Date.valueOf(jTableAssesmentsTable.getValueAt(selectedRow, 3).toString());
                java.sql.Date dueDate = java.sql.Date.valueOf(jTableAssesmentsTable.getValueAt(selectedRow, 4).toString());
                int percentageWorth = Integer.parseInt(jTableAssesmentsTable.getValueAt(selectedRow, 5).toString());
                int studentId = Integer.parseInt(jTextFieldStudentID.getText());

                // Start transaction
                con.setAutoCommit(false);

                // Update Assessments table (without grade)
                String sqlAssessments = "UPDATE Assesments SET Name=?, Given_Date=?, Due_Date=?, Percentage_Worth=? WHERE Assigments_ID=?";
                PreparedStatement prest = con.prepareStatement(sqlAssessments);
                prest.setString(1, name);
                prest.setDate(2, givenDate);
                prest.setDate(3, dueDate);
                prest.setInt(4, percentageWorth);
                prest.setInt(5, assessmentId);
                prest.executeUpdate();
                prest.close();

                // Update student grade in Assessments_has_Students table
                String sqlGrade = "UPDATE Assesments_has_Students SET Grade=? WHERE Assigments_ID=? AND Student_ID=?";
                PreparedStatement prestGrade = con.prepareStatement(sqlGrade);
                prestGrade.setInt(1, grade);
                prestGrade.setInt(2, assessmentId);
                prestGrade.setInt(3, studentId);
                prestGrade.executeUpdate();
                prestGrade.close();

                // Commit both updates
                con.commit();

                JOptionPane.showMessageDialog(this, "Assessment updated successfully");

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error updating assessment: " + e);
            }
            // Disable table editing after saving
            jTableAssesmentsTable.setEnabled(false);
            jButtonEditDetails.setEnabled(true);
            jButtonAddRecords.setEnabled(true);
            jButtonEditRecords.setEnabled(true);
            jButtonSaveDetails.setEnabled(false);
            jButtonCancelDetails.setEnabled(false);
            jButtonSaveRecords.setEnabled(false);
            jButtonCancelRecords.setEnabled(false);

        } else if (uploadAssesments) {
            // Set assessment values from input fields
            assesments.setAssigmentID(Integer.parseInt(jTextFieldAssigmentID.getText()));
            assesments.setAssesmentTitle(jTextFieldAssigmentName.getText());
            assesments.setGrade(Integer.parseInt(jTextFieldGrade.getText()));
            assesments.setGivenDate(java.sql.Date.valueOf(jTextFieldGivenDate.getText()));
            assesments.setDueDate(java.sql.Date.valueOf(jTextFieldDueDate.getText()));
            assesments.setPercentageWorth(Integer.parseInt(jTextFieldCPercentageWorth.getText()));
            module.setModuleCode(jTextFieldModuleCode.getText());

            try {
                Connection con = DriverManager.getConnection(url + dbName, userName, password);

                // Insert new assessment
                String sqlAssesments = "";
                PreparedStatement prestAssesments = con.prepareStatement(sqlAssesments);
                prestAssesments.setInt(1, assesments.getAssigmentID());
                prestAssesments.setString(2, assesments.getAssesmentTitle());
                prestAssesments.setDate(3, assesments.getGivenDate());
                prestAssesments.setDate(4, assesments.getDueDate());
                prestAssesments.setInt(5, assesments.getPercentageWorth());
                prestAssesments.executeUpdate();
                prestAssesments.close();

                // Insert into junction table to link assessment with student and module
                String sqlJunction = "INSERT INTO assesments_has_students (Assigments_ID, Student_ID, Module_Code, Grade) VALUES (?, ?, ?, ?);";
                PreparedStatement prestJunction = con.prepareStatement(sqlJunction);
                prestJunction.setInt(1, assesments.getAssigmentID());
                prestJunction.setInt(2, student.getStudentID());
                prestJunction.setString(3, module.getModuleCode());
                prestJunction.setInt(4, assesments.getGrade()); // add grade here
                prestJunction.executeUpdate();
                prestJunction.close();

                JOptionPane.showMessageDialog(this, "Assessment added successfully");

                // Refresh table to show the new entry
                jButtonSearch.doClick();

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error updating assessment: " + e);
            }

        }

        // Reset buttons and clear assessment input fields
        jButtonEditDetails.setEnabled(true);
        jButtonAddRecords.setEnabled(true);
        jButtonEditRecords.setEnabled(true);
        jButtonSaveDetails.setEnabled(false);
        jButtonCancelDetails.setEnabled(false);

        jButtonSaveRecords.setEnabled(false);
        jButtonCancelRecords.setEnabled(false);
        jTextFieldAssigmentID.setText("");
        jTextFieldAssigmentName.setText("");
        jTextFieldGrade.setText("");
        jTextFieldGivenDate.setText("");
        jTextFieldCPercentageWorth.setText("");
        jTextFieldModuleCode.setText("");
        jTextFieldDueDate.setText("");
    }//GEN-LAST:event_jButtonSaveRecordsActionPerformed

    private void jTextFieldStudentFirstNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldStudentFirstNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldStudentFirstNameActionPerformed

    private void jTextFieldAddressLine1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldAddressLine1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldAddressLine1ActionPerformed

    private void jTextFieldAddedLine3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldAddedLine3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldAddedLine3ActionPerformed

    private void jTextFieldCountyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldCountyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldCountyActionPerformed

    private void jButtonEditDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonEditDetailsActionPerformed
        if (startframe) {
            // Enable editing of student details
            editdetails = true;
            setFieldsEnabledStudent();

            // Disable other buttons to prevent conflicts
            jButtonEditDetails.setEnabled(false);
            jButtonAddRecords.setEnabled(false);
            jButtonEditRecords.setEnabled(false);
            jButtonSaveRecords.setEnabled(false);
            jButtonCancelRecords.setEnabled(false);

            // Enable save and cancel buttons for student details
            jButtonSaveDetails.setEnabled(true);
            jButtonCancelDetails.setEnabled(true);
        } else {
            JOptionPane.showMessageDialog(rootPane, "Please search for a student first.");
        }

    }//GEN-LAST:event_jButtonEditDetailsActionPerformed

    private void jTextFieldStudentIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextFieldStudentIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextFieldStudentIDActionPerformed

    private void jButtonSaveDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSaveDetailsActionPerformed
        if (editdetails) { // check if user is in edit mode

            try {
                Connection con = DriverManager.getConnection(url + dbName, userName, password);

                // SQL statement to update student details based on Student_ID
                String sql = "UPDATE students SET Name = ?, Surname = ?, PPS_Number = ?, DOB = ?, Address_One = ?, Address_Two = ?, Adress_Three = ?, County = ? WHERE Student_ID = ?;";
                PreparedStatement prest = con.prepareStatement(sql);

                // Set values from input fields into the que
                prest.setString(1, jTextFieldStudentFirstName.getText());
                prest.setString(2, jTextFieldStudentSurname.getText());
                prest.setString(3, jTextFieldPPSNumber.getText());
                prest.setDate(4, java.sql.Date.valueOf(jTextFieldDOB.getText()));
                prest.setString(5, jTextFieldAddressLine1.getText());
                prest.setString(6, jTextFieldAddressLine2.getText());
                prest.setString(7, jTextFieldAddedLine3.getText());
                prest.setString(8, jTextFieldCounty.getText());
                prest.setInt(9, Integer.parseInt(jTextFieldStudentID.getText()));

                // Execute update
                prest.executeUpdate();

                setFieldsDisabledStudent();// disable fields after saving
                JOptionPane.showMessageDialog(this, "Student details updated successfully");

            } catch (SQLException e) {
                System.out.println("Not Connected " + e);
                JOptionPane.showMessageDialog(this, "Error updating student details " + e);
            }
        }

        searchStudent();// refresh student list
        editdetails = false; // reset edit flag

        // Reset buttons to default state
        jButtonEditDetails.setEnabled(true);
        jButtonAddRecords.setEnabled(true);
        jButtonEditRecords.setEnabled(true);
        jButtonSaveDetails.setEnabled(false);
        jButtonCancelDetails.setEnabled(false);
        jButtonSaveRecords.setEnabled(false);
        jButtonCancelRecords.setEnabled(false);
    }//GEN-LAST:event_jButtonSaveDetailsActionPerformed

    private void jButtonCancelDetailsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonCancelDetailsActionPerformed
        // Ask user to confirm cancel action
        int answer = JOptionPane.showConfirmDialog(
                this,
                "Are you sure you want to cancel?",
                "Confirm",
                JOptionPane.YES_NO_OPTION
        );

        if (answer == JOptionPane.YES_OPTION) {
            editdetails = false; // exit edit mode

            // Disable student input fields
            setFieldsDisabledStudent();

            // Reset buttons
            jButtonEditDetails.setEnabled(true);
            jButtonAddRecords.setEnabled(true);
            jButtonEditRecords.setEnabled(true);
            jButtonSaveDetails.setEnabled(false);
            jButtonCancelDetails.setEnabled(false);
            jButtonSaveRecords.setEnabled(false);
            jButtonCancelRecords.setEnabled(false);

            // Restore original student data into text fields
            jTextFieldStudentFirstName.setText(student.getName());
            jTextFieldStudentSurname.setText(student.getSurname());
            jTextFieldStudentID.setText(student.getStudentID() + "");
            jTextFieldPPSNumber.setText(student.getPPSNumber());
            jTextFieldDOB.setText(student.getDOB() + "");
            jTextFieldAddressLine1.setText(student.getAddressOne());
            jTextFieldAddressLine2.setText(student.getAddressTwo());
            jTextFieldAddedLine3.setText(student.getAddressThree());
            jTextFieldCounty.setText(student.getCounty());
            jTextFieldClassGroupCode.setText(student.getClassGroup());
        }

    }//GEN-LAST:event_jButtonCancelDetailsActionPerformed

    private void searchStudent() {

        try {
            Connection con = DriverManager.getConnection(url + dbName, userName, password);

            // SQL query to get students taught by the logged-in teacher 
            String sql = "SELECT DISTINCT s.Student_ID, s.Name, s.Surname FROM students s JOIN class_group cg ON s.Class_Group_Code = cg.Class_Group_Code JOIN module m ON cg.Course_Code = m.Course_Code WHERE m.Staff_ID = ?;";
            PreparedStatement prest = con.prepareStatement(sql);
            prest.setInt(1, this.teacher.getStaffID());
            ResultSet res = prest.executeQuery();

            jComboBoxSearch.removeAllItems(); // clear previous items

            // Add students to combo box
            while (res.next()) {
                String combobox = res.getInt("Student_ID") + " - " + res.getString("Surname") + " , " + res.getString("Name");
                jComboBoxSearch.addItem(combobox);// display as "ID - Surname , Name" 
            }

        } catch (SQLException e) {
            // Display an error message if the database connection fails
            System.out.print("Not Connected");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ReflectiveOperationException | javax.swing.UnsupportedLookAndFeelException ex) {
            logger.log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> new TutorStudentsFrame().setVisible(true));
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButtonAddRecords;
    private javax.swing.JButton jButtonCancelDetails;
    private javax.swing.JButton jButtonCancelRecords;
    private javax.swing.JButton jButtonEditDetails;
    private javax.swing.JButton jButtonEditRecords;
    private javax.swing.JButton jButtonLogOut;
    private javax.swing.JButton jButtonMyClasses;
    private javax.swing.JButton jButtonSaveDetails;
    private javax.swing.JButton jButtonSaveRecords;
    private javax.swing.JButton jButtonSearch;
    private javax.swing.JComboBox<String> jComboBoxSearch;
    private javax.swing.JFrame jFrame1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabelAddressLine1;
    private javax.swing.JLabel jLabelAddressLine2;
    private javax.swing.JLabel jLabelAddressLine3;
    private javax.swing.JLabel jLabelAssigmentID;
    private javax.swing.JLabel jLabelAssigmentName;
    private javax.swing.JLabel jLabelClassCode;
    private javax.swing.JLabel jLabelCounty;
    private javax.swing.JLabel jLabelCourseID;
    private javax.swing.JLabel jLabelCourseIDTitle;
    private javax.swing.JLabel jLabelCourseName;
    private javax.swing.JLabel jLabelCourseNameTitle;
    private javax.swing.JLabel jLabelCourseNameTitle1;
    private javax.swing.JLabel jLabelCourseNameTitle2;
    private javax.swing.JLabel jLabelCourseNameTitle3;
    private javax.swing.JLabel jLabelDOB;
    private javax.swing.JLabel jLabelDueDate;
    private javax.swing.JLabel jLabelEmail;
    private javax.swing.JLabel jLabelEmail1;
    private javax.swing.JLabel jLabelEmail2;
    private javax.swing.JLabel jLabelGivenDate;
    private javax.swing.JLabel jLabelGrade;
    private javax.swing.JLabel jLabelLogo;
    private javax.swing.JLabel jLabelModuleCode;
    private javax.swing.JLabel jLabelPPS;
    private javax.swing.JLabel jLabelPercentageWorth;
    private javax.swing.JLabel jLabelSeacrhStudent;
    private javax.swing.JLabel jLabelStudentFirstName;
    private javax.swing.JLabel jLabelStudentID;
    private javax.swing.JLabel jLabelStudentSurname;
    private javax.swing.JLabel jLabelStudentsDetails;
    private javax.swing.JLabel jLabelStudentsDetails1;
    private javax.swing.JLabel jLabelStudentsDetails2;
    private javax.swing.JLabel jLabelTeacherName;
    private javax.swing.JLabel jLabelTeacherName1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanelSearchStudents;
    private javax.swing.JPanel jPanelStudentInfo;
    private javax.swing.JPanel jPanelStudentInfo1;
    private javax.swing.JPanel jPanelStudentInfo2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTableAssesmentsTable;
    private javax.swing.JTextField jTextFieldAddedLine3;
    private javax.swing.JTextField jTextFieldAddressLine1;
    private javax.swing.JTextField jTextFieldAddressLine2;
    private javax.swing.JTextField jTextFieldAssigmentID;
    private javax.swing.JTextField jTextFieldAssigmentName;
    private javax.swing.JTextField jTextFieldCPercentageWorth;
    private javax.swing.JTextField jTextFieldClassGroupCode;
    private javax.swing.JTextField jTextFieldCounty;
    private javax.swing.JTextField jTextFieldDOB;
    private javax.swing.JTextField jTextFieldDueDate;
    private javax.swing.JTextField jTextFieldGivenDate;
    private javax.swing.JTextField jTextFieldGrade;
    private javax.swing.JTextField jTextFieldModuleCode;
    private javax.swing.JTextField jTextFieldPPSNumber;
    private javax.swing.JTextField jTextFieldStudentFirstName;
    private javax.swing.JTextField jTextFieldStudentID;
    private javax.swing.JTextField jTextFieldStudentSurname;
    // End of variables declaration//GEN-END:variables
}
