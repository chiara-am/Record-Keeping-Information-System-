/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FinalProject;

import javax.swing.JOptionPane;
import java.sql.Date;
import java.util.Calendar;

/**
 *
 * @author elich
 */
public class StudentClass extends PersonClass {

    /**
     * @return the StudentID
     */
    public int getStudentID() {
        return StudentID;
    }

    /**
     * @param StudentID the StudentID to set
     */
    public void setStudentID(int StudentID) {
        this.StudentID = StudentID;
    }

    /**
     * @return the ClassGroup
     */
    public String getClassGroup() {
        return ClassGroup;
    }

    /**
     * @param ClassGroup the ClassGroup to set
     */
    public void setClassGroup(String ClassGroup) {
        this.ClassGroup = ClassGroup;
    }
    private int StudentID;

    private String ClassGroup;

   
   

}
