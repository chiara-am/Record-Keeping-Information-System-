/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FinalProject;

/**
 *
 * @author elich
 */
public class ModuleClass {

    /**
     * @return the ModuleCode
     */
    public String getModuleCode() {
        return ModuleCode;
    }

    /**
     * @param ModuleCode the ModuleCode to set
     */
    public void setModuleCode(String ModuleCode) {
        this.ModuleCode = ModuleCode;
    }


    /**
     * @return the ModuleTitle
     */
    public String getModuleTitle() {
        return ModuleTitle;
    }

    /**
     * @param ModuleTitle the ModuleTitle to set
     */
    public void setModuleTitle(String ModuleTitle) {
        this.ModuleTitle = ModuleTitle;
    }
    
    
    private String ModuleCode;

    private String ModuleTitle;
    
}
