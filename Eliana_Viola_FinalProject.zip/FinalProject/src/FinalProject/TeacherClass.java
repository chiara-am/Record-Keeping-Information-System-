/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FinalProject;

/**
 *
 * @author elich
 */
public class TeacherClass extends PersonClass {

    /**
     * @return the StaffID
     */
    public int getStaffID() {
        return StaffID;
    }

    /**
     * @param StaffID the StaffID to set
     */
    public void setStaffID(int StaffID) {
        this.StaffID = StaffID;
    }

    /**
     * @return the Email
     */
    public String getEmail() {
        return Email;
    }

    /**
     * @param Email the Email to set
     */
    public void setEmail(String Email) {
        this.Email = Email;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * @param Password the Password to set
     */
    public void setPassword(String Password) {
        this.Password = Password;
    }
     private int StaffID;
     private String Email;
     private String Password;
}
